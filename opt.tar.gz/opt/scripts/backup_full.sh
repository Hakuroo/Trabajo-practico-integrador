#!/bin/bash

# Mostrar ayuda
if [[ "$1" == "-help" ]]; then
  echo "Uso: $0 [origen] [destino]"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# Verificar que los argumentos existan
if [[ ! -d "$ORIGEN" ]]; then
  echo "Directorio de origen no válido: $ORIGEN"
  exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
  echo "Directorio de destino no válido: $DESTINO"
  exit 1
fi

NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN"

echo "Backup creado: $ARCHIVO"
